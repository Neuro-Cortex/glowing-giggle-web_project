#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>


int main()
{
    int a = 10;
    printf("Surprise! Your shell is hacked!\n");
}


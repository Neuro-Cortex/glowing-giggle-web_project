#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>

int main()
{
    if(fork() == 0)
    {
        printf("Hello from child\n");
        char *myargs[3];
        myargs[0] = strdup("ls");
        myargs[1] = strdup("-1");
        myargs[2] = NULL;

        // myargs[0] = strdup("./p5");
        // myargs[1] = NULL;
        // myargs[2] = NULL;
        execvp(myargs[0], myargs);
        printf("This should not print out\n");
    }else
    {
        wait(NULL);
        printf("Hello from parent\n");
    }
}


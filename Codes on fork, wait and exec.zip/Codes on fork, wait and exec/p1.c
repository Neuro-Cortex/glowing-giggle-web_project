#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
    printf("Hello world (pid:%d)\n", (int) getpid());
    int rc = fork();

    //parent process will get child id
    //child process will get 0
    //if fork fails, it will return -1

    if(rc < 0)
    {
        exit(1);
    }else if(rc == 0)
    {
        printf("Hello, I am child (pid:%d)\n", (int) getpid());
    }else
    {
        printf("Hello, I am parent of %d (pid:%d)\n", rc, (int) getpid());
    }
    return 0;
}

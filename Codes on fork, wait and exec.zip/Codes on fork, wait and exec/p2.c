#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
    int a = 10;
    printf("Before calling fork\n");
    fork();
    fork();
    printf("After calling fork\n");
    printf("a = %d\n",a);
    return 0;
}
